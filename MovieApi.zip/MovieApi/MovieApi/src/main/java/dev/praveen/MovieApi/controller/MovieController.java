package dev.praveen.MovieApi.controller;

import dev.praveen.MovieApi.model.Movie;
import dev.praveen.MovieApi.model.Review;
import dev.praveen.MovieApi.service.MovieService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@CrossOrigin(origins = "http://localhost:3000")
@RequestMapping("/api/p1/movies")
public class MovieController {
    @Autowired
    private MovieService movieService;
    @GetMapping
    public ResponseEntity<List<Movie>> getAllMovies(){
        return new ResponseEntity<List<Movie>>(movieService.allMovies(),HttpStatus.OK);
    }

    @GetMapping("/{imdbId}")
    public ResponseEntity<Movie> getMovie(@PathVariable String imdbId){
        Movie movie = movieService.getMovie((imdbId));
        return new ResponseEntity<Movie>(movie,HttpStatus.OK);
    }
}
