package dev.praveen.MovieApi.service;

import dev.praveen.MovieApi.model.Movie;
import dev.praveen.MovieApi.repository.MovieRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class MovieService {
    @Autowired
    private MovieRepository movieRepo;

    public List<Movie> allMovies(){
        return movieRepo.findAll();
    }

    public Movie getMovie(String imdbID){
        return movieRepo.findByImdbId(imdbID);
    }
}
